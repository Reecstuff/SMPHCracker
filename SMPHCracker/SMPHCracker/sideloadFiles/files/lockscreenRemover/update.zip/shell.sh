#!/sbin/sh

rm -rf /data/system/*.key

